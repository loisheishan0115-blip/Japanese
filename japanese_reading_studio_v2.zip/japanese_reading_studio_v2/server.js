import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
app.disable("x-powered-by");
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/essay", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI is not configured on the server yet. Add OPENAI_API_KEY in your host's environment variables." });
    }
    const { topic, length, words, extraIdeas, level } = req.body || {};
    const safeTopic = String(topic || "Self-introduction").slice(0, 100);
    const count = Math.max(3, Math.min(8, Number(length) || 5));
    const safeWords = Array.isArray(words) ? words.slice(0, 30).map(x => String(x).slice(0, 60)) : [];
    const safeIdeas = String(extraIdeas || "").slice(0, 500);
    const prompt = `Create a short Japanese learning essay for a learner at basic level.
Topic: ${safeTopic}
Number of sentences: exactly ${count}
Vocabulary to try to include naturally: ${safeWords.join(", ") || "(choose beginner-friendly words)"}
Additional learner ideas: ${safeIdeas || "(none)"}
Rules: use natural, simple Japanese appropriate for JLPT N5-ish beginner practice; do not force words that do not fit; avoid complex kanji where possible; give accurate Hepburn romaji and a natural English translation for each sentence. If a word has multiple readings, use the reading appropriate to the sentence. Return only JSON matching this shape:
{"sentences":[{"japanese":"...","romaji":"...","english":"..."}]}
Do not add markdown fences or extra keys.`;
    const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
    const apiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "You are a careful Japanese language tutor. Return valid JSON only and prioritize accurate Japanese, romaji, and English." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4,
        max_tokens: 1400
      })
    });
    const raw = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      const message = raw?.error?.message || `AI provider returned HTTP ${apiResponse.status}.`;
      return res.status(502).json({ error: message });
    }
    const content = raw?.choices?.[0]?.message?.content;
    if (!content) return res.status(502).json({ error: "The AI provider returned an empty response." });
    let parsed;
    try { parsed = JSON.parse(content); } catch {
      return res.status(502).json({ error: "The AI response was not valid JSON. Please try again." });
    }
    if (!Array.isArray(parsed.sentences)) return res.status(502).json({ error: "The AI response did not contain a sentences list." });
    const sentences = parsed.sentences.slice(0, 8).map(s => ({
      japanese: String(s.japanese || "").slice(0, 500),
      romaji: String(s.romaji || "").slice(0, 500),
      english: String(s.english || "").slice(0, 500)
    })).filter(s => s.japanese);
    return res.json({ sentences });
  } catch (err) {
    console.error("Essay generation error:", err);
    return res.status(500).json({ error: "Unexpected server error. Check the server logs and try again." });
  }
});

app.listen(PORT, () => console.log(`Japanese Reading Studio listening on port ${PORT}`));

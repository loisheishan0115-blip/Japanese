# Japanese Reading Studio v2

A beginner/basic-level Japanese reading practice website with:
- Japanese passages with romaji and English meaning toggles
- Browser text-to-speech (`ja-JP`) for passages, essays, and custom text
- Selectable vocabulary
- AI-generated short essays with Japanese, romaji, and English translation
- Offline template fallback
- Backend health check

## Files
- `public/index.html` — website layout
- `public/app.js` — browser interactions
- `server.js` — Node.js backend; keeps the API key private
- `package.json` — Node dependencies and commands
- `.env.example` — environment variable template (not a real key)
- `.gitignore` — excludes secrets and dependencies

## Run locally
Requirements: Node.js 20 or later and an internet connection for AI essay generation.

1. Extract the ZIP.
2. Open a terminal in the extracted project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Set your environment variables. Easiest is to copy `.env.example` to `.env`, then use a local environment loader, or set them in your terminal. This project intentionally does not load `.env` by itself. A straightforward option is to install dotenv (`npm install dotenv`) and add `import "dotenv/config";` as the first line of `server.js`. Keep `.env` out of source control.
5. Add your own OpenAI API key as `OPENAI_API_KEY`. Optionally set `OPENAI_MODEL` to a model available to your API account. API access and billing may be separate from a ChatGPT subscription.
6. Start:
   ```bash
   npm start
   ```
7. Visit `http://localhost:3000`.

### Setting variables without dotenv
macOS/Linux:
```bash
export OPENAI_API_KEY="your_key_here"
export OPENAI_MODEL="gpt-4.1-mini"
npm start
```
PowerShell:
```powershell
$env:OPENAI_API_KEY="your_key_here"
$env:OPENAI_MODEL="gpt-4.1-mini"
npm start
```

If using `.env`, either add dotenv as described above or use a host's environment-variable settings. Never paste your real key into public JavaScript, HTML, screenshots, or a public repository.

## Deploy online
This project needs a Node.js host that can run a persistent Express server. Example platforms include Render, Railway, or another Node-compatible host. Exact UI labels/pricing may change; check the chosen host's current documentation.

Typical deployment:
1. Put these project files in a private/local folder and push them to a Git repository.
2. Create a new web service from that repository on your chosen host.
3. Set the build/install command to `npm install` (often automatic) and start command to `npm start`.
4. Add `OPENAI_API_KEY` as a secret environment variable in the host dashboard. Optionally set `OPENAI_MODEL`.
5. Deploy and open the HTTPS URL provided by the host.
6. Test “Check AI connection”, then generate an essay.

Do not deploy the API key in frontend files or a public `.env` file. Keep provider usage limits and spending controls in mind. Hosting and API usage may cost money.

## API and cost requirements
- Read-aloud pronunciation uses browser/device speech synthesis and does not require an AI API.
- The offline essay template does not require an AI API.
- AI essay generation requires an OpenAI API key, network access, an API account with access to the selected model, and any required API billing/credits. A ChatGPT subscription does not automatically include API usage.
- The backend calls the OpenAI Chat Completions API using `OPENAI_API_KEY` on the server. The default model is configured by `OPENAI_MODEL` (`gpt-4.1-mini`); change it if that model is unavailable to your account.
- API pricing and model availability can change; check current official API documentation and pricing before use.
- Never put your secret API key in `public/app.js` or `public/index.html`. The server route keeps the key out of browser responses.
- This starter has no login, rate limiting, database, or user accounts. Before sharing widely, add rate limiting, abuse protection, and any access controls you need so strangers cannot run up API usage.
- The server limits input sizes and sentence count but is not a production-hardened service.

## Known limitations
- Browser speech synthesis depends on the device's Japanese voice. It may not be available on every device/browser.
- The built-in kana-to-romaji helper is basic and is not a kanji reading engine. Kanji readings can be ambiguous.
- AI-generated Japanese and romaji can contain errors. Use it for practice and verify important language with a trusted dictionary or teacher.
- This is a starter learning project, not a fully tested production application.

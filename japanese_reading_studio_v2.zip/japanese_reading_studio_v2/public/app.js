const $=id=>document.getElementById(id);
const passages={
 intro:[
  {jp:"こんにちは。",romaji:"Konnichiwa.",en:"Hello."},
  {jp:"わたしは学生です。",romaji:"Watashi wa gakusei desu.",en:"I am a student."},
  {jp:"日本語を勉強しています。",romaji:"Nihongo o benkyou shite imasu.",en:"I am studying Japanese."},
  {jp:"どうぞよろしくおねがいします。",romaji:"Douzo yoroshiku onegaishimasu.",en:"Nice to meet you."}],
 weekend:[
  {jp:"土曜日に友だちに会います。",romaji:"Doyoubi ni tomodachi ni aimasu.",en:"I meet my friend on Saturday."},
  {jp:"いっしょに昼ごはんを食べます。",romaji:"Issho ni hirugohan o tabemasu.",en:"We eat lunch together."},
  {jp:"午後に本を読みます。",romaji:"Gogo ni hon o yomimasu.",en:"I read a book in the afternoon."},
  {jp:"とても楽しい週末です。",romaji:"Totemo tanoshii shuumatsu desu.",en:"It is a very fun weekend."}],
 food:[
  {jp:"わたしはすしが好きです。",romaji:"Watashi wa sushi ga suki desu.",en:"I like sushi."},
  {jp:"ラーメンも好きです。",romaji:"Raamen mo suki desu.",en:"I also like ramen."},
  {jp:"日本の食べ物はおいしいです。",romaji:"Nihon no tabemono wa oishii desu.",en:"Japanese food is delicious."}]
};
const vocab=[
 ["わたし","watashi","I; me"],["学生","gakusei","student"],["日本語","nihongo","Japanese language"],["勉強","benkyou","study"],
 ["学校","gakkou","school"],["友だち","tomodachi","friend"],["好き","suki","like; favourite"],["食べ物","tabemono","food"],
 ["おいしい","oishii","delicious"],["本","hon","book"],["音楽","ongaku","music"],["毎日","mainichi","every day"],
 ["行きます","ikimasu","go"],["食べます","tabemasu","eat"],["です","desu","is; am; are"],["こんにちは","konnichiwa","hello"],
 ["家","ie","home; house"],["楽しい","tanoshii","fun"],["映画","eiga","movie"],["コーヒー","koohii","coffee"],
 ["読みます","yomimasu","read"],["会います","aimasu","meet"],["週末","shuumatsu","weekend"],["昼ごはん","hirugohan","lunch"]
];
let showRomaji=true,showMeaning=true,showCustom=false;
const selected=new Set();
function renderPassage(){
 const rows=passages[$("passageSelect").value];
 $("passageContent").innerHTML=rows.map(x=>`<div class="passage-line"><div class="jp">${esc(x.jp)}</div>${showRomaji?`<div class="romaji">${esc(x.romaji)}</div>`:""}${showMeaning?`<div class="meaning">${esc(x.en)}</div>`:""}</div>`).join("");
}
function renderWords(){
 $("wordList").innerHTML="";
 vocab.forEach((w,i)=>{
  const card=document.createElement("div");card.className="word"+(selected.has(i)?" selected":"");
  const label=document.createElement("label");const cb=document.createElement("input");cb.type="checkbox";cb.checked=selected.has(i);cb.setAttribute("aria-label","Select "+w[0]);
  cb.addEventListener("change",()=>{cb.checked?selected.add(i):selected.delete(i);renderWords();});
  label.append(cb,document.createTextNode(" Use this word"));const jp=document.createElement("div");jp.className="jp";jp.textContent=w[0];
  const ro=document.createElement("div");ro.className="romaji";ro.textContent=w[1];const en=document.createElement("div");en.className="hint";en.textContent=w[2];card.append(label,jp,ro,en);$("wordList").append(card);
 });
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function speak(text){if(!text.trim())return;if(!("speechSynthesis"in window)){alert("Text-to-speech is not supported in this browser.");return;}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="ja-JP";u.rate=.85;const v=speechSynthesis.getVoices().find(v=>v.lang.toLowerCase().startsWith("ja"));if(v)u.voice=v;speechSynthesis.speak(u);}
function toRomaji(text){
 const m={"あ":"a","い":"i","う":"u","え":"e","お":"o","か":"ka","き":"ki","く":"ku","け":"ke","こ":"ko","さ":"sa","し":"shi","す":"su","せ":"se","そ":"so","た":"ta","ち":"chi","つ":"tsu","て":"te","と":"to","な":"na","に":"ni","ぬ":"nu","ね":"ne","の":"no","は":"ha","ひ":"hi","ふ":"fu","へ":"he","ほ":"ho","ま":"ma","み":"mi","む":"mu","め":"me","も":"mo","や":"ya","ゆ":"yu","よ":"yo","ら":"ra","り":"ri","る":"ru","れ":"re","ろ":"ro","わ":"wa","を":"o","ん":"n","が":"ga","ぎ":"gi","ぐ":"gu","げ":"ge","ご":"go","ざ":"za","じ":"ji","ず":"zu","ぜ":"ze","ぞ":"zo","だ":"da","ぢ":"ji","づ":"zu","で":"de","ど":"do","ば":"ba","び":"bi","ぶ":"bu","べ":"be","ぼ":"bo","ぱ":"pa","ぴ":"pi","ぷ":"pu","ぺ":"pe","ぽ":"po","ぁ":"a","ぃ":"i","ぅ":"u","ぇ":"e","ぉ":"o","ゃ":"ya","ゅ":"yu","ょ":"yo","っ":""};
 const combo={"きゃ":"kya","きゅ":"kyu","きょ":"kyo","しゃ":"sha","しゅ":"shu","しょ":"sho","ちゃ":"cha","ちゅ":"chu","ちょ":"cho","にゃ":"nya","にゅ":"nyu","にょ":"nyo","ひゃ":"hya","ひゅ":"hyu","ひょ":"hyo","みゃ":"mya","みゅ":"myu","みょ":"myo","りゃ":"rya","りゅ":"ryu","りょ":"ryo","ぎゃ":"gya","ぎゅ":"gyu","ぎょ":"gyo","じゃ":"ja","じゅ":"ju","じょ":"jo","びゃ":"bya","びゅ":"byu","びょ":"byo","ぴゃ":"pya","ぴゅ":"pyu","ぴょ":"pyo"};
 const a=[...text];let out="";
 for(let i=0;i<a.length;i++){let pair=a[i]+(a[i+1]||"");if(combo[pair]){out+=combo[pair];i++;continue;}if(a[i]==="っ"&&a[i+1]){let n=m[a[i+1]]||"";out+=(n[0]||"");continue;}out+=m[a[i]]||a[i];}
 return out;
}
async function requestEssay(){
 const btn=$("generate");btn.disabled=true;setStatus("essayStatus","Generating your essay…");
 const payload={topic:$("topic").value,length:Number($("length").value),words:[...selected].map(i=>vocab[i][0]),extraIdeas:$("extraWords").value.trim(),level:"basic"};
 try{
  const res=await fetch("/api/essay",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const data=await res.json().catch(()=>({error:"The server returned an unreadable response."}));
  if(!res.ok)throw new Error(data.error||"Essay generation failed.");
  renderEssay(data);setStatus("essayStatus","AI essay ready.");
 }catch(e){setStatus("essayStatus",e.message+" You can still use the offline template below.",true);}
 finally{btn.disabled=false;}
}
function renderEssay(data){
 const sentences=Array.isArray(data.sentences)?data.sentences:[];
 if(!sentences.length)throw new Error("The AI response did not contain any sentences.");
 $("essayOutput").innerHTML=sentences.map(s=>`<div class="essay-line"><div class="jp">${esc(s.japanese)}</div><div class="romaji">${esc(s.romaji||"Romaji not provided")}</div><div class="meaning">${esc(s.english||"")}</div></div>`).join("");
 $("essayOutput").dataset.japanese=sentences.map(s=>s.japanese).join("\n");
}
function setStatus(id,msg,error=false){const el=$(id);el.textContent=msg;el.classList.toggle("error",error);}
function offlineEssay(){
 const words=[...selected].map(i=>vocab[i][0]);const x=words.length?words:["日本語","音楽"];
 const topic=$("topic").value;let s;
 if(topic==="Favourite food")s=[`わたしは${x[0]}が好きです。`,`${x[1]||"すし"}も好きです。`,`とてもおいしいです。`];
 else if(topic==="My daily routine")s=["わたしは毎日、学校へ行きます。",`家で${x[0]}を勉強します。`,"毎日がんばります。"];
 else if(topic==="School life")s=["わたしは学生です。","学校で日本語を勉強します。","学校は楽しいです。"];
 else if(topic==="My friends")s=["わたしには友だちがいます。",`友だちと${x[0]}が好きです。`,"いっしょに話します。"];
 else if(topic==="My weekend")s=["週末に友だちに会います。",`いっしょに${x[0]}をします。`,"とても楽しいです。"];
 else s=["こんにちは。わたしは学生です。",`わたしは${x[0]}が好きです。`,"日本語を勉強しています。"];
 $("essayOutput").innerHTML=s.map(j=>`<div class="essay-line"><div class="jp">${esc(j)}</div><div class="romaji">${esc(toRomaji(j))}</div><div class="meaning">Review this sentence's meaning with a dictionary or teacher.</div></div>`).join("");
 $("essayOutput").dataset.japanese=s.join("\n");
 setStatus("essayStatus","Offline template created. It uses simple examples and may need grammar review.");
}
$("passageSelect").addEventListener("change",renderPassage);
$("speakPassage").addEventListener("click",()=>speak(passages[$("passageSelect").value].map(x=>x.jp).join(" ")));
$("toggleRomaji").addEventListener("click",()=>{showRomaji=!showRomaji;renderPassage();});
$("toggleMeaning").addEventListener("click",()=>{showMeaning=!showMeaning;renderPassage();});
$("generate").addEventListener("click",requestEssay);$("template").addEventListener("click",offlineEssay);
$("speakEssay").addEventListener("click",()=>speak($("essayOutput").dataset.japanese||$("essayOutput").innerText));
$("copyEssay").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("essayOutput").dataset.japanese||$("essayOutput").innerText);setStatus("essayStatus","Japanese essay copied.");}catch{setStatus("essayStatus","Select the Japanese text and copy it manually.",true);}});
$("speakCustom").addEventListener("click",()=>speak($("customText").value));
$("showCustomRomaji").addEventListener("click",()=>{showCustom=!showCustom;$("customRomaji").textContent=showCustom?toRomaji($("customText").value):"";});
$("customText").addEventListener("input",()=>{if(showCustom)$("customRomaji").textContent=toRomaji($("customText").value);});
$("copyCustom").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("customText").value);}catch{}});
$("checkHealth").addEventListener("click",async()=>{setStatus("healthStatus","Checking…");try{const r=await fetch("/api/health");const d=await r.json();setStatus("healthStatus",d.aiConfigured?"Server online; AI key is configured.":"Server online, but AI key is not configured yet.",!d.aiConfigured);}catch(e){setStatus("healthStatus","Backend not reachable. If you opened a local HTML file directly, start the server or deploy the whole project.",true);}});
renderPassage();renderWords();
